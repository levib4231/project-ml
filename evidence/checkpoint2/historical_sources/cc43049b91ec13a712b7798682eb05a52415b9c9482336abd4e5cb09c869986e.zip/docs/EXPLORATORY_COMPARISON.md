# Noisy-only comparison pilot

This follow-up does not modify or replace the completed T4 or MPS medical
benchmarks. Neither demonstrated the predeclared NGPS advantage. Existing test
subjects are already exposed; later scoring on them is exploratory only.

## Implemented first stage

`ngps/comparison.py` and `scripts/comparison_pilot.py` run a bounded feasibility
study, not a claim of improved denoising quality:

- subject04 training observations only, sigma 0.06;
- 32 central training slices, batch1, width16, original optimizer and seed42;
- independently initialized matched 32- and 64-update schedules (1 and 2 epochs);
- full NGPS, blindspot, adjacent, NGPS without RC, NGPS without dynamic loss;
- first 16 noisy validation batches, fixed masks, monitoring only;
- fixed final checkpoint; no ranking, tuning, or winner selection from scores;
- independently declared MPS pilot safety cap of 600 seconds per run, not a
  reused T4 performance budget. Record measured times; halt on overrun.

All variants retain the same initialization, shuffled samples, deterministic
crops, and optimizer schedule. The two ablations retain the original active-pixel
normalization, omit only the designated term, and do not rescale other terms.
They still compute matching and neighbor forwards, so their timings do not
estimate an optimized implementation's savings. Training losses differ by
objective and must not be ranked as denoising quality.

The runner freezes a hashed protocol before training, refuses existing output
directories, records source snapshots per run, and preserves partial evidence
on failure. New ablations cannot pass the frozen Checkpoint 2 validator as full
NGPS. Default training behavior is unchanged.

Opt-in gradient diagnostics observe the L2 norm without clipping, fail on
nonfinite norms, and have a regression test for identical CPU model updates.
A fixed training crop supplies all/dynamic-region cost quantiles, clamped
retrieval-offset distances, Top-K spatial spread, and mask fractions. The crop
is a local diagnostic, not representative population evidence.

```bash
python NGPS/scripts/comparison_pilot.py \
  --manifest outputs/checkpoint2/medical/mps_full_prepared/manifest.json \
  --config outputs/checkpoint2/medical/mps_full_run/training.yaml \
  --output-dir outputs/checkpoint2/exploratory/comparison_pilot_v1 \
  --device mps
```

## Next stages (not implemented or authorized by pilot outcomes)

1. Predeclare full-training matched 531/1062/2148-update convergence experiments,
   pilot their MPS cost, and freeze realistic workload caps before execution.
2. Run full-workload loss ablations; keep variants separately named.
3. Compare one larger capacity across all required trained objectives.
4. Consider confidence weighting only as a separately tested method change.
5. Freeze all final candidates before scoring; obtain untouched subjects for
   independent confirmation. Never use clean arrays for tuning/selection.

The experiment index lives under `outputs/checkpoint2/exploratory/`; frozen
historical outputs must not be rewritten to accommodate source changes.
